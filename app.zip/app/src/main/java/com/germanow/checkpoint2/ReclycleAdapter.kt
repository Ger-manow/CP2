package com.germanow.checkpoint2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.ToggleButton
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter: RecyclerView.Adapter<RecyclerAdapter.ViewHolder>()
    {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerAdapter.ViewHolder
        {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.card_layout, parent, false)
            return ViewHolder(v)
        }

        override fun onBindViewHolder(holder: RecyclerAdapter.ViewHolder, position: Int)
        {
            TODO("Not yet implemented")
        }

        override fun getItemCount(): Int
        {
            TODO("Not yet implemented")
        }

        inner class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView)
        {
            var itemToggle: ToggleButton
            var itemText: TextView

            init
            {
                itemToggle = itemView.findViewById(R.id.taskStatus)
                itemText = itemView.findViewById(R.id.taskName)
            }
        }
    }